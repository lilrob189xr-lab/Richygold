import type { Metadata } from "next";
import { branches } from "@/data/branches";
import { photosOf } from "@/data/photos";
import { siteUrl } from "@/lib/site";
import Photo from "@/components/ui/Photo";
import OpenStatus from "@/components/i18n/OpenStatus";
import ContactCta from "@/components/brand/ContactCta";

export const metadata: Metadata = {
  title: "สาขาของเรา",
  description: "สาขาของ KAI RICHY: เซ็นทรัล ภูเก็ต ฟลอเรสต้า (KAI RICHY) และตลาดท้ายรถนาคา (ริชชี่โกลด์หลอมทอง) ที่อยู่ เวลาเปิด และเบอร์โทร",
};

// Structured data uses verified branch facts only: no ratings, reviews or prices.
const jsonLd = branches.map((b) => ({
  "@context": "https://schema.org",
  "@type": "JewelryStore",
  name: b.id === "kai-richy-floresta" ? "KAI RICHY สาขาเซ็นทรัล ภูเก็ต ฟลอเรสต้า" : "ริชชี่โกลด์หลอมทอง สาขาตลาดท้ายรถนาคา (RICHY GOLD)",
  telephone: b.phoneHref.replace("tel:", ""),
  address: { "@type": "PostalAddress", streetAddress: b.address, addressRegion: "ภูเก็ต", addressCountry: "TH" },
  openingHours: b.id === "kai-richy-floresta" ? "Mo-Su 10:00-20:00" : "Mo-Su 09:00-19:30",
  hasMap: b.mapsUrl,
  ...(siteUrl ? { url: siteUrl + "/locations" } : {}),
}));

// Lead photograph per branch (the rest follow in a uniform grid).
const LEAD: Record<string, string> = { "kai-richy-floresta": "CEBE7D37", "richy-gold-naka": "636A36E8" };

export default function LocationsPage() {
  return (
    <div className="air">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <section className="page-hero">
        <div className="container">
          <p className="label gold">Locations</p>
          <h1>สาขาของเรา</h1>
          <p className="reading lead">สองสาขาในจังหวัดภูเก็ต</p>
        </div>
      </section>

      {branches.map((b, idx) => {
        const all = photosOf(b.id);
        const lead = all.find((p) => p.id === LEAD[b.id]) ?? all[0];
        // 394AFAAD (candid selfie) stays in the inventory but is not placed on this page.
        const rest = all.filter((p) => p !== lead && p.id !== "394AFAAD");
        return (
          <section key={b.id} id={b.id} className={`section ${idx % 2 === 0 ? "section--white" : "section--ivory"}`}>
            <div className="container loc-block">
              <div className="loc-block__info">
                <p className="loc-no en">{b.number}</p>
                <p className="label">สาขา {b.number}</p>
                <h2>{b.brandName}</h2>
                <p className="bcard__name">{b.nameTh}</p>
                <dl className="facts facts--large">
                  {b.locationNote && (<><dt>ตำแหน่ง</dt><dd>{b.locationNote}</dd></>)}
                  <dt>ที่อยู่</dt><dd>{b.address}</dd>
                  <dt>เวลาเปิดทำการ</dt><dd>{b.hours}<OpenStatus openMin={b.openMin} closeMin={b.closeMin} /></dd>
                  <dt>โทรศัพท์</dt><dd><a href={b.phoneHref}>{b.phoneDisplay}</a></dd>
                  {b.services.xray && (<><dt>ตรวจสอบด้วยเครื่อง X-Ray</dt><dd>มีบริการ</dd></>)}
                  {b.services.goldMelting && (<><dt>บริการหลอมทอง</dt><dd>มีบริการ (เฉพาะสาขานี้)</dd></>)}
                </dl>
                <div className="inquiry">
                  <a className="btn btn--primary" href={b.phoneHref}>โทร {b.phoneDisplay}</a>
                  <a className="btn btn--secondary" href={b.mapsUrl} target="_blank" rel="noopener noreferrer">เปิดใน Google Maps</a>
                </div>
              </div>
              <div className="loc-photos">
                <div className="loc-photos__lead frame-offset" style={{ marginBottom: 8 }}>
                  <Photo photo={lead} ratio="4 / 3" focus="center 35%" priority={idx === 0} sizes="(min-width:1024px) 55vw, 100vw" />
                </div>
                {rest.map((p) => (
                  <Photo key={p.id} photo={p} ratio="4 / 3" focus="center 32%" sizes="(min-width:1024px) 27vw, 50vw" />
                ))}
              </div>
            </div>
          </section>
        );
      })}

      <ContactCta />
    </div>
  );
}
