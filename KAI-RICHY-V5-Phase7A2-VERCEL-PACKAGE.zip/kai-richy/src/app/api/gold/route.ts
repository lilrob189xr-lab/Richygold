import { NextResponse } from "next/server";
import { fetchGold } from "@/lib/gold";

// Server-side proxy: the browser never calls the third-party API directly and no key is needed.
// Upstream is cached for 60 s (fetch revalidate); CDN may serve stale for 5 min while refreshing.
export const dynamic = "force-dynamic";

export async function GET() {
  const r = await fetchGold();
  if (!r.ok) return NextResponse.json({ ok: false, error: r.error }, { status: 503, headers: { "Cache-Control": "no-store" } });
  return NextResponse.json(r, { headers: { "Cache-Control": "public, s-maxage=60, stale-while-revalidate=300" } });
}
