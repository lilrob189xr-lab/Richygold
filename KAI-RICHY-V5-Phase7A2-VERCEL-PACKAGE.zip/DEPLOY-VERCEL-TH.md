# KAI RICHY — วิธีนำขึ้น Vercel (ภาษาไทย)

## ไฟล์นี้คืออะไร
- โฟลเดอร์ `kai-richy/` คือโปรเจกต์ Next.js + React + TypeScript ต้นฉบับจาก ZIP ที่ผู้ใช้ส่งมา
- คงโค้ด หน้าเว็บ ข้อมูลสินค้า รูปภาพ และ API ไว้ตามต้นฉบับ
- ไฟล์นี้เพิ่มเฉพาะคู่มือ ไม่ได้แก้โค้ด ไม่ได้แปลงเป็น HTML แบบ static และไม่ได้ deploy

## วิธีขึ้น Vercel
1. แตก ZIP นี้ แล้วเข้าโฟลเดอร์ `kai-richy/`
2. นำโฟลเดอร์ `kai-richy/` ขึ้น GitHub เป็น repository โดยเก็บโครงสร้างไฟล์ทั้งหมดไว้
3. เข้า Vercel แล้วเลือก Add New → Project
4. Import Git Repository ที่อัปโหลดไว้
5. ตรวจค่าตั้งต้นดังนี้
   - Framework Preset: Next.js
   - Root Directory: `./` (ถ้า repository มีไฟล์จาก `kai-richy/` อยู่ที่ root)
   - Build Command: `npm run build`
   - Install Command: `npm install`
   - Output Directory: ปล่อยค่าเริ่มต้นของ Next.js
6. กด Deploy หลังจากตรวจ Environment Variables ที่จำเป็นแล้ว

## ข้อควรระวัง
- ZIP ต้นฉบับไม่มี `package-lock.json` จึงอาจมีการ resolve เวอร์ชัน dependency ใหม่ในขั้นติดตั้ง
- มี API route ที่ `src/app/api/gold/route.ts` และมีการเรียก API ราคาทองจากฝั่งเซิร์ฟเวอร์ ต้องตรวจ `src/lib/gold.ts` ก่อนตั้งค่า secret หรือ deploy จริง
- อย่าเปลี่ยนเป็น Static HTML Export เพราะจะกระทบ API route และพฤติกรรม Catalog/Product แบบไดนามิก
- คู่มือนี้ไม่ใช่ผลยืนยันว่า build ผ่าน การทดสอบ build และการ deploy จริงยังไม่ได้ทำ
